import Groq from '@groqapi/groq-sdk';
import { GROQ_API_KEY, systemPrompt } from '../config/groq';

const groq = new Groq({
  apiKey: GROQ_API_KEY,
});

export async function getChatResponse(userMessage: string): Promise<string> {
  try {
    const completion = await groq.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: userMessage,
        },
      ],
      model: 'mixtral-8x7b-32768',
      temperature: 0.7,
      max_tokens: 1024,
      stream: false,
    });

    return completion.choices[0]?.message?.content || 'I apologize, but I couldn\'t generate a response.';
  } catch (error) {
    console.error('Error calling Groq API:', error);
    return 'I apologize, but I encountered an error while processing your request.';
  }
}