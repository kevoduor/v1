import React, { useState, useEffect } from 'react';
import { Brain } from 'lucide-react';
import { SearchBar } from './components/SearchBar';
import { ResponseBubble } from './components/ResponseBubble';
import { getChatResponse } from './services/groqService';

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

function App() {
  const [messages, setMessages] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        handleSearch(transcript);
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognition);
    }
  }, []);

  const handleSearch = async (query: string) => {
    setMessages(prev => [...prev, query]);
    setIsLoading(true);
    
    try {
      const response = await getChatResponse(query);
      setMessages(prev => [...prev, response]);
    } catch (error) {
      console.error('Error getting response:', error);
      setMessages(prev => [...prev, 'Sorry, I encountered an error. Please try again.']);
    }
    
    setIsLoading(false);
  };

  const toggleListening = () => {
    if (!recognition) return;
    
    if (isListening) {
      recognition.stop();
    } else {
      recognition.start();
    }
    setIsListening(!isListening);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col items-center space-y-8">
          <div className="flex items-center space-x-3">
            <Brain className="w-8 h-8 text-purple-600" />
            <h1 className="text-3xl font-bold text-gray-800">Niah</h1>
          </div>
          
          <SearchBar
            onSearch={handleSearch}
            isListening={isListening}
            onToggleListening={toggleListening}
          />

          <div className="w-full max-w-3xl space-y-4">
            {messages.map((message, index) => (
              <ResponseBubble key={index} message={message} />
            ))}
            {isLoading && <ResponseBubble message="" isLoading={true} />}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;