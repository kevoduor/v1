import React from 'react';

interface ResponseBubbleProps {
  message: string;
  isLoading?: boolean;
}

export const ResponseBubble: React.FC<ResponseBubbleProps> = ({ message, isLoading }) => {
  if (isLoading) {
    return (
      <div className="flex items-center space-x-2 p-4 bg-white rounded-lg shadow-md">
        <div className="flex space-x-1">
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" />
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 bg-white rounded-lg shadow-md">
      <p className="text-gray-800 whitespace-pre-wrap">{message}</p>
    </div>
  );
}