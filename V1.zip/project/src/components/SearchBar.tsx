import React, { useState } from 'react';
import { Search, Mic } from 'lucide-react';

interface SearchBarProps {
  onSearch: (query: string) => void;
  isListening: boolean;
  onToggleListening: () => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  onSearch,
  isListening,
  onToggleListening,
}) => {
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-3xl">
      <div className="relative flex items-center">
        <div className="absolute left-4">
          <Search className="w-5 h-5 text-gray-400" />
        </div>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full px-12 py-4 bg-white rounded-full shadow-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
          placeholder="Ask anything..."
        />
        <button
          type="button"
          onClick={onToggleListening}
          className={`absolute right-4 p-2 rounded-full transition-colors ${
            isListening ? 'bg-purple-100 text-purple-600' : 'text-gray-400 hover:text-purple-600'
          }`}
        >
          <Mic className="w-5 h-5" />
        </button>
      </div>
    </form>
  );
}